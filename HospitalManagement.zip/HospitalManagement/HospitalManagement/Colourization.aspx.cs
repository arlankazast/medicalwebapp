﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HospitalManagement
{
    public partial class Colourization : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Process.Start("C:\\Users\\HP A8\\Desktop\\kolorowanie2\\kolorowanie2\\bin\\Debug");
        }
        int x, y;
        Color pg, pc, p;




        //        private void button1_Click(object sender, EventArgs e)

    }
       
}



