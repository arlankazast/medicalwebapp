﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagement
{
    public partial class NewAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["New"] != null)
            {
                Form.Text = Session["New"].ToString();
            }
            else
            {
                Response.Redirect("home.aspx");
            }





            if(IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KanirmaConnections"].ConnectionString);
                conn.Open();
                string checkuser = "SELECT count(*) FROM UserData WHERE Username ='" + UID.Text + "'";
                SqlCommand com = new SqlCommand(checkuser,conn);
                int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
                if (temp == 1)
                {
                    Response.Write("Username already exists");


                    return;
                }
                
                conn.Close();
            }
        }

        protected void create_Click(object sender, EventArgs e)
        {
            try{

            if(IsPostBack)
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["KanirmaConnections"].ConnectionString);
                conn.Open();

                string InsertQuery = "Insert into UserData (Username,password,Email,job) values(@u,@p,@e,@j)";
                SqlCommand com = new SqlCommand(InsertQuery,conn);
                com.Parameters.AddWithValue("@u",UID.Text);
                com.Parameters.AddWithValue("@p",newpass.Text);
                com.Parameters.AddWithValue("@e",EmailID.Text);
                com.Parameters.AddWithValue("@j",jobID.SelectedItem.ToString());
                com.ExecuteNonQuery();


                Response.Redirect("Admin.aspx");

                

                conn.Close();
            }
        }
            catch(Exception ex)
            {
                Response.Write("Something went wrong"+ ex.ToString());
            }
    }

        protected void LogOut_Click1(object sender, EventArgs e)
        {
            Session["New"] = null;
            Response.Redirect("home.aspx");
        }
  }
}