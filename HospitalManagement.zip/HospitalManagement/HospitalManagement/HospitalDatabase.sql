﻿CREATE TABLE [dbo].[Table] (
    [ID] NCHAR(10) NOT NULL,
    [Username] NCHAR(20) NULL, 
    [password] NCHAR(20) NULL, 
    [Email] NCHAR(50) NULL, 
    [job] NCHAR(20) NULL, 
    PRIMARY KEY CLUSTERED ([ID])
);

