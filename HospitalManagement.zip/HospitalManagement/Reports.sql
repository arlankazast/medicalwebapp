﻿CREATE TABLE [dbo].[Reports]
(
	[Id] INT NOT NULL PRIMARY KEY
)
